import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AssessmentPage from './pages/AssessmentPage';
import AASBS2AssessmentPage from './pages/AASBS2AssessmentPage';
import AASBS1AssessmentPage from './pages/AASBS1AssessmentPage';
import ResultsPage from './pages/ResultsPage';
import SavedAssessmentsPage from './pages/SavedAssessmentsPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/assessment" element={<AssessmentPage />} />
        <Route path="/aasb-s2" element={<AASBS2AssessmentPage />} />
        <Route path="/aasb-s1" element={<AASBS1AssessmentPage />} />
        <Route path="/results" element={<ResultsPage />} />
        <Route path="/saved" element={<SavedAssessmentsPage />} />
      </Routes>
    </Router>
  );
}

export default App;
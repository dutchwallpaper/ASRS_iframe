import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, CheckCircle, AlertTriangle, ArrowRight } from 'lucide-react';
import { UserResponse } from '../types';
import { aasbs1Questions } from '../data/aasbs1Questions';

interface AASBS1ResultProps {
  responses: UserResponse[];
}

const AASBS1Result: React.FC<AASBS1ResultProps> = ({ responses }) => {
  const navigate = useNavigate();
  
  // Calculate compliance scores
  const calculateScore = (questions: typeof aasbs1Questions) => {
    let total = 0;
    questions.forEach(question => {
      const response = responses.find(r => r.questionId === question.id);
      if (response) {
        if (response.answer === 'Yes') total += 1;
        else if (response.answer === 'Partially') total += 0.5;
      }
    });
    return Math.round((total / questions.length) * 100);
  };
  
  const overallScore = calculateScore(aasbs1Questions);
  
  // Determine compliance level
  let complianceLevel = 'High Risk';
  let statusColor = 'text-red-600';
  let statusBg = 'bg-red-50';
  
  if (overallScore >= 75) {
    complianceLevel = 'Low Risk';
    statusColor = 'text-green-600';
    statusBg = 'bg-green-50';
  } else if (overallScore >= 40) {
    complianceLevel = 'Medium Risk';
    statusColor = 'text-orange-600';
    statusBg = 'bg-orange-50';
  }
  
  // Generate recommendations
  const recommendations = responses
    .filter(response => response.answer === 'No' || response.answer === 'Partially')
    .map(response => {
      const question = aasbs1Questions.find(q => q.id === response.questionId);
      return {
        text: question?.text,
        suggestion: question?.mitigationSuggestion
      };
    });
  
  return (
    <div className="bg-white rounded-lg shadow-md p-8">
      <div className="flex justify-center mb-4">
        {overallScore >= 60 ? (
          <CheckCircle size={48} className="text-green-600" />
        ) : (
          <AlertTriangle size={48} className="text-orange-600" />
        )}
      </div>
      
      <h2 className="text-2xl font-bold text-center mb-6">
        AASB S1 Assessment Results
      </h2>
      
      <div className={`${statusBg} rounded-lg p-6 mb-8`}>
        <div className="text-center">
          <h3 className="text-lg font-semibold mb-2">Overall Score</h3>
          <p className={`text-4xl font-bold ${statusColor}`}>{overallScore}%</p>
          <p className="text-lg text-gray-600 mt-2">{complianceLevel}</p>
        </div>
      </div>
      
      {recommendations.length > 0 && (
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4">Priority Actions</h3>
          <div className="space-y-4">
            {recommendations.map((rec, index) => (
              <div key={index} className="border-l-4 border-orange-500 pl-4 py-2">
                <h4 className="font-medium mb-1">{rec.text}</h4>
                <p className="text-sm text-gray-600">{rec.suggestion}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="flex flex-col items-center gap-4">
        <button
          onClick={() => navigate('/results')}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-md transition-colors w-full max-w-md justify-center"
        >
          View Combined Results
          <ArrowRight size={20} />
        </button>
        
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-md transition-colors w-full max-w-md justify-center"
        >
          <Home size={20} />
          Return to Home
        </button>
      </div>
    </div>
  );
};

export default AASBS1Result;
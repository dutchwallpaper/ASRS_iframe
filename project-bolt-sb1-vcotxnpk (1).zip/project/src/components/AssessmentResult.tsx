import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, AlertCircle, CheckCircle, ArrowRight } from 'lucide-react';
import { UserResponse } from '../types';

interface AssessmentResultProps {
  responses: UserResponse[];
}

const AssessmentResult: React.FC<AssessmentResultProps> = ({ responses }) => {
  const navigate = useNavigate();
  
  // Get the first question's response
  const firstResponse = responses.find(r => r.questionId === 1);
  
  if (firstResponse?.answer === 'No') {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <div className="flex justify-center mb-4">
          <AlertCircle size={48} className="text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold mb-4">You do not need to Report</h2>
        <p className="text-gray-600 mb-8">
          Based on your response, your organization is not required to report under the Australian Sustainability Reporting Standards at this time.
        </p>
        <button
          onClick={() => navigate('/')}
          className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-md transition-colors mx-auto"
        >
          <Home size={20} />
          Return to Home
        </button>
      </div>
    );
  }

  // Determine reporting group based on responses
  let group: number | null = null;
  let reportingDate = "1 July 2024";

  // Asset owners path
  if (responses.find(r => r.questionId === 2)?.answer === 'Yes') {
    if (responses.find(r => r.questionId === 3)?.answer === '$5 billion or more') {
      group = 1;
    } else {
      group = 2;
    }
  }
  // NGER reporters path
  else if (responses.find(r => r.questionId === 4)?.answer === 'Yes') {
    group = 1;
  }
  // Revenue path
  else {
    const revenue = responses.find(r => r.questionId === 5)?.answer;
    if (revenue === '$500 million or more') {
      group = 1;
    } else if (revenue === '$200 million to $499 million') {
      const assets = responses.find(r => r.questionId === 6)?.answer;
      if (assets === '$1 billion or more') {
        group = 1;
      } else {
        const employees = responses.find(r => r.questionId === 7)?.answer;
        group = employees === '500 or more' ? 1 : 2;
      }
    } else {
      group = 3;
    }
  }

  // Adjust reporting date based on group
  if (group === 2) {
    reportingDate = "1 July 2025";
  } else if (group === 3) {
    reportingDate = "1 July 2026";
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-8">
      <div className="flex justify-center mb-4">
        <CheckCircle size={48} className="text-green-600" />
      </div>
      <h2 className="text-2xl font-bold text-center mb-6">
        Reporting Requirements Determined
      </h2>
      <div className="bg-blue-50 rounded-lg p-6 mb-8">
        <h3 className="text-xl font-semibold text-blue-900 mb-4">
          Your Organization's Reporting Status
        </h3>
        <p className="text-lg text-blue-800 mb-2">
          You are required to report under <span className="font-bold">Group {group}</span>
        </p>
        <p className="text-blue-700">
          Your reporting obligations commence from <span className="font-bold">{reportingDate}</span>
        </p>
      </div>
      <div className="flex flex-col items-center gap-4">
        <button
          onClick={() => navigate('/aasb-s2')}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-md transition-colors w-full max-w-md justify-center"
        >
          Continue to AASB S2 Assessment
          <ArrowRight size={20} />
        </button>
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-md transition-colors w-full max-w-md justify-center"
        >
          <Home size={20} />
          Return to Home
        </button>
      </div>
    </div>
  );
};

export default AssessmentResult;
import React from 'react';
import { ClipboardCheck, LogOut, User } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { Link } from 'react-router-dom';

const Header: React.FC = () => {
  const { currentUser, isAuthenticated, logout } = useAuthStore();
  
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <ClipboardCheck className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">
                Arch's Sustainability Compliance Assessment
              </span>
            </Link>
          </div>
          
          {isAuthenticated && currentUser && (
            <div className="flex items-center">
              <div className="flex items-center mr-4">
                <div className="bg-blue-100 rounded-full p-2 mr-2">
                  <User size={18} className="text-blue-600" />
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-700">
                    {currentUser.name}
                  </span>
                  {currentUser.organisation && (
                    <p className="text-xs text-gray-500">
                      {currentUser.position ? `${currentUser.position}, ` : ''}{currentUser.organisation}
                    </p>
                  )}
                </div>
              </div>
              
              <button
                onClick={logout}
                className="flex items-center text-gray-500 hover:text-gray-700"
                aria-label="Log out"
              >
                <LogOut size={18} />
                <span className="ml-1 text-sm">Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
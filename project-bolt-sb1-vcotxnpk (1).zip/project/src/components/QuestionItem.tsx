import React, { useState } from 'react';
import { Info, HelpCircle } from 'lucide-react';
import { QuestionType, UserResponse } from '../types';
import classNames from 'classnames';

interface QuestionItemProps {
  question: QuestionType;
  response?: UserResponse;
  onAnswerChange: (questionId: number, answer: string) => void;
  isVisible: boolean;
}

const QuestionItem: React.FC<QuestionItemProps> = ({
  question,
  response,
  onAnswerChange,
  isVisible
}) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [showError, setShowError] = useState(false);
  
  if (!isVisible) return null;

  const handleAnswerChange = (answer: string) => {
    setShowError(false);
    onAnswerChange(question.id, answer);
  };
  
  return (
    <div className="mb-8 p-6 bg-white rounded-lg shadow-md">
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-lg font-semibold flex-1 pr-4">
          Question {question.id}: {question.text}
          <span className="text-red-500 ml-1">*</span>
        </h3>
        <button
          type="button"
          className="text-blue-500 hover:text-blue-700 focus:outline-none"
          onClick={() => setShowTooltip(!showTooltip)}
          aria-label="Show more information"
        >
          <HelpCircle size={20} />
        </button>
      </div>
      
      {showTooltip && (
        <div className="mb-4 p-4 bg-blue-50 rounded-md text-sm">
          <div className="flex items-start">
            <Info size={18} className="text-blue-500 mr-2 mt-0.5" />
            <p className="text-gray-700">
              {question.mitigationSuggestion}
            </p>
          </div>
        </div>
      )}
      
      <div className="mt-4">
        <div className="flex flex-wrap gap-4">
          {question.options.map((option) => (
            <label
              key={option}
              className={classNames(
                "flex items-center p-3 border rounded-md cursor-pointer transition-colors",
                {
                  "border-gray-300 hover:bg-gray-50": response?.answer !== option,
                  "border-green-500 bg-green-50": response?.answer === option,
                  "border-red-300": showError && !response
                }
              )}
            >
              <input
                type="radio"
                name={`question-${question.id}`}
                value={option}
                checked={response?.answer === option}
                onChange={() => handleAnswerChange(option)}
                className="mr-2"
                required
              />
              {option}
            </label>
          ))}
        </div>
        {showError && !response && (
          <p className="text-red-500 text-sm mt-2">Please select an answer for this question</p>
        )}
      </div>
    </div>
  );
};

export default QuestionItem;
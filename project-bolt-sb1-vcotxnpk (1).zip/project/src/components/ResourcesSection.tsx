import React from 'react';
import { ExternalLink, BookOpen, FileText, HelpCircle } from 'lucide-react';

const ResourcesSection: React.FC = () => {
  const resources = [
    {
      title: 'AASB Sustainability Reporting Standards',
      description: 'Official standards and guidelines from the Australian Accounting Standards Board.',
      link: 'https://www.aasb.gov.au/sustainability',
      icon: <FileText size={20} className="text-blue-500" />
    },
    {
      title: 'TCFD Recommendations',
      description: 'Task Force on Climate-related Financial Disclosures framework and implementation guides.',
      link: 'https://www.fsb-tcfd.org/recommendations/',
      icon: <BookOpen size={20} className="text-green-500" />
    },
    {
      title: 'Climate Disclosure Standards Board',
      description: 'Resources for environmental and climate change reporting.',
      link: 'https://www.cdsb.net/frameworks',
      icon: <FileText size={20} className="text-blue-500" />
    },
    {
      title: 'Global Reporting Initiative',
      description: 'GRI Standards for sustainability reporting.',
      link: 'https://www.globalreporting.org/standards/',
      icon: <BookOpen size={20} className="text-green-500" />
    },
    {
      title: 'Sustainability Reporting FAQ',
      description: 'Frequently asked questions about sustainability reporting requirements.',
      link: '#',
      icon: <HelpCircle size={20} className="text-purple-500" />
    }
  ];
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold mb-6">Resources & References</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {resources.map((resource, index) => (
          <a
            key={index}
            href={resource.link}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-start p-4 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors"
          >
            <div className="mr-3 mt-1">{resource.icon}</div>
            <div>
              <h3 className="font-medium flex items-center">
                {resource.title}
                <ExternalLink size={14} className="ml-1 text-gray-400" />
              </h3>
              <p className="text-sm text-gray-600 mt-1">{resource.description}</p>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

export default ResourcesSection;
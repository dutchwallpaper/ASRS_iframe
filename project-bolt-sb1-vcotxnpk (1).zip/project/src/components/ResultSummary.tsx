import React from 'react';
import { Download, CheckCircle, XCircle, AlertTriangle, Info } from 'lucide-react';
import { AssessmentResult, UserResponse } from '../types';
import { generatePDF } from '../utils/pdfGenerator';

interface ResultSummaryProps {
  result: AssessmentResult;
  responses: UserResponse[];
  userName: string;
}

const ResultSummary: React.FC<ResultSummaryProps> = ({ result, responses, userName }) => {
  const handleDownloadPDF = () => {
    const doc = generatePDF(result, responses, userName);
    doc.save('sustainability-compliance-report.pdf');
  };
  
  // Determine compliance status and colour
  let statusColor = 'bg-red-500';
  let statusIcon = <XCircle className="text-white" size={24} />;
  
  if (result.overallComplianceScore >= 80) {
    statusColor = 'bg-green-500';
    statusIcon = <CheckCircle className="text-white" size={24} />;
  } else if (result.overallComplianceScore >= 60) {
    statusColor = 'bg-yellow-500';
    statusIcon = <AlertTriangle className="text-white" size={24} />;
  } else if (result.overallComplianceScore >= 40) {
    statusColor = 'bg-orange-500';
    statusIcon = <AlertTriangle className="text-white" size={24} />;
  }
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Assessment Results</h2>
        <button
          onClick={handleDownloadPDF}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors"
        >
          <Download size={18} />
          Download Report
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gray-50 p-4 rounded-md">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Overall Compliance</h3>
          <div className="flex items-center">
            <div className={`${statusColor} text-white rounded-full w-12 h-12 flex items-center justify-center mr-3`}>
              {statusIcon}
            </div>
            <div>
              <p className="text-3xl font-bold">{result.overallComplianceScore}%</p>
              <p className="text-sm text-gray-600">{result.complianceLevel}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-md">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Mandatory Compliance</h3>
          <p className="text-3xl font-bold">{result.mandatoryComplianceScore}%</p>
          <p className="text-sm text-gray-600">Required standards</p>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-md">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Voluntary Compliance</h3>
          <p className="text-3xl font-bold">{result.voluntaryComplianceScore}%</p>
          <p className="text-sm text-gray-600">Additional standards</p>
        </div>
      </div>
      
      <div className="mb-6 p-4 bg-gray-50 rounded-md">
        <h3 className="text-lg font-semibold mb-2">Compliance Level Legend</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center">
            <div className="bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
              <CheckCircle size={18} />
            </div>
            <div>
              <p className="font-medium">Compliant</p>
              <p className="text-xs text-gray-600">80-100%</p>
            </div>
          </div>
          <div className="flex items-center">
            <div className="bg-yellow-500 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
              <AlertTriangle size={18} />
            </div>
            <div>
              <p className="font-medium">Partially Compliant</p>
              <p className="text-xs text-gray-600">60-79%</p>
            </div>
          </div>
          <div className="flex items-center">
            <div className="bg-orange-500 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
              <AlertTriangle size={18} />
            </div>
            <div>
              <p className="font-medium">At Risk</p>
              <p className="text-xs text-gray-600">40-59%</p>
            </div>
          </div>
          <div className="flex items-center">
            <div className="bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
              <XCircle size={18} />
            </div>
            <div>
              <p className="font-medium">High Risk</p>
              <p className="text-xs text-gray-600">0-39%</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div>
          <h3 className="text-xl font-semibold mb-4">Compliant Areas</h3>
          {result.compliantAreas.length > 0 ? (
            <ul className="space-y-2 text-gray-700">
              {result.compliantAreas.map((area, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle size={18} className="text-green-500 mr-2 mt-0.5" />
                  <span>{area}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500 italic">No compliant areas identified.</p>
          )}
        </div>
        
        <div>
          <h3 className="text-xl font-semibold mb-4">Areas Needing Attention</h3>
          {result.nonCompliantAreas.length > 0 ? (
            <ul className="space-y-2 text-gray-700">
              {result.nonCompliantAreas.map((area, index) => (
                <li key={index} className="flex items-start">
                  <AlertTriangle size={18} className="text-orange-500 mr-2 mt-0.5" />
                  <span>{area}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500 italic">No areas needing attention identified.</p>
          )}
        </div>
      </div>
      
      {result.mitigationSuggestions.length > 0 && (
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4">Priority Improvement Areas</h3>
          <div className="space-y-4">
            {result.mitigationSuggestions.slice(0, 5).map((item) => (
              <div key={item.questionId} className={`border-l-4 ${item.isMandatory ? 'border-red-500' : 'border-yellow-500'} pl-4 py-2`}>
                <div className="flex items-center mb-1">
                  <h4 className="font-medium">{item.questionText}</h4>
                  {item.isMandatory && (
                    <span className="ml-2 text-xs bg-red-100 text-red-800 px-2 py-0.5 rounded-full">Mandatory</span>
                  )}
                </div>
                <p className="text-sm text-gray-600">{item.suggestion}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div>
        <h3 className="text-xl font-semibold mb-4">Recommended Next Steps</h3>
        <div className="bg-blue-50 p-4 rounded-md mb-4">
          <div className="flex items-start">
            <Info size={20} className="text-blue-600 mr-2 mt-0.5" />
            <p className="text-sm text-blue-800">
              These recommendations are based on industry best practices and Australian Sustainability Reporting Standards requirements.
            </p>
          </div>
        </div>
        <ol className="list-decimal list-inside space-y-3 text-gray-700">
          <li className="pl-2">
            <span className="font-medium">Establish a Sustainability Governance Framework</span>
            <p className="text-sm ml-6 mt-1">Develop clear roles, responsibilities, and reporting lines for sustainability oversight at board and management levels.</p>
          </li>
          <li className="pl-2">
            <span className="font-medium">Conduct a Comprehensive Climate Risk Assessment</span>
            <p className="text-sm ml-6 mt-1">Identify and assess both physical and transition risks specific to your industry and operations following TCFD guidelines.</p>
          </li>
          <li className="pl-2">
            <span className="font-medium">Implement Robust Data Collection Systems</span>
            <p className="text-sm ml-6 mt-1">Establish processes and controls for collecting, verifying, and reporting sustainability data, particularly GHG emissions.</p>
          </li>
          <li className="pl-2">
            <span className="font-medium">Develop a Climate Transition Plan</span>
            <p className="text-sm ml-6 mt-1">Create a detailed roadmap with specific actions, timelines, and responsibilities to address climate-related risks and opportunities.</p>
          </li>
          <li className="pl-2">
            <span className="font-medium">Engage with Key Stakeholders</span>
            <p className="text-sm ml-6 mt-1">Establish structured engagement processes with investors, customers, suppliers, and other stakeholders on sustainability matters.</p>
          </li>
          <li className="pl-2">
            <span className="font-medium">Consider External Assurance</span>
            <p className="text-sm ml-6 mt-1">Engage with assurance providers to enhance the credibility and reliability of your sustainability disclosures.</p>
          </li>
          <li className="pl-2">
            <span className="font-medium">Schedule Regular Compliance Reviews</span>
            <p className="text-sm ml-6 mt-1">Conduct follow-up assessments every 6-12 months to track progress and adjust strategies as needed.</p>
          </li>
        </ol>
      </div>
    </div>
  );
};

export default ResultSummary;
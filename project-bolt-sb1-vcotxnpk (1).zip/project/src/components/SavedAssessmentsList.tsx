import React from 'react';
import { FileText, Trash2 } from 'lucide-react';
import { SavedAssessment } from '../types';

interface SavedAssessmentsListProps {
  assessments: SavedAssessment[];
  onLoad: (assessmentId: string) => void;
  onDelete: (assessmentId: string) => void;
}

const SavedAssessmentsList: React.FC<SavedAssessmentsListProps> = ({
  assessments,
  onLoad,
  onDelete
}) => {
  if (assessments.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No saved assessments found.</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {assessments.map((assessment) => {
        const date = new Date(assessment.date);
        const formattedDate = date.toLocaleDateString('en-AU', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
        
        const score = assessment.result?.complianceScore || 'Not calculated';
        
        return (
          <div 
            key={assessment.id}
            className="bg-white rounded-lg shadow-md p-4 flex items-center justify-between"
          >
            <div className="flex items-center">
              <div className="bg-blue-100 p-2 rounded-full mr-4">
                <FileText className="text-blue-600" size={20} />
              </div>
              <div>
                <h3 className="font-medium">Assessment from {formattedDate}</h3>
                <p className="text-sm text-gray-600">
                  Compliance Score: {typeof score === 'number' ? `${score}%` : score}
                </p>
              </div>
            </div>
            
            <div className="flex space-x-2">
              <button
                onClick={() => onLoad(assessment.id)}
                className="px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
              >
                Load
              </button>
              <button
                onClick={() => onDelete(assessment.id)}
                className="p-1 text-red-500 hover:text-red-700 transition-colors"
                aria-label="Delete assessment"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default SavedAssessmentsList;
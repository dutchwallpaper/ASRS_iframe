import { QuestionType } from '../types';

export const aasbs1Questions: QuestionType[] = [
  {
    id: 1,
    text: "Has your organisation identified and disclosed material sustainability-related risks and opportunities beyond climate?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Conduct a comprehensive materiality assessment covering all aspects of sustainability (e.g., environmental, social, governance). Consider industry-specific issues and stakeholder concerns."
  },
  {
    id: 2,
    text: "Has your organisation disclosed information about its governance of sustainability-related risks and opportunities?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Ensure clear disclosure of board and management responsibilities for sustainability. Consider establishing a dedicated sustainability committee if not already in place."
  },
  {
    id: 3,
    text: "Has your organisation disclosed its processes for identifying, assessing, and managing sustainability-related risks?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Integrate sustainability risk management into your overall risk management framework. Describe specific processes and tools used for sustainability risk assessment."
  },
  {
    id: 4,
    text: "Has your organisation disclosed its strategy for addressing sustainability-related risks and opportunities?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Develop a comprehensive sustainability strategy aligned with your business strategy. Include short, medium, and long-term objectives and action plans."
  },
  {
    id: 5,
    text: "Has your organisation disclosed metrics and targets used to assess, manage, and monitor sustainability performance?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Establish clear, measurable KPIs for material sustainability issues. Consider aligning with recognized frameworks (e.g., GRI, SASB) for industry-specific metrics."
  },
  {
    id: 6,
    text: "Has your organisation considered and disclosed the impacts of sustainability-related risks and opportunities on its financial position, performance, and cash flows?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Quantify financial impacts where possible. Consider both current and potential future impacts across different time horizons."
  },
  {
    id: 7,
    text: "Has your organisation disclosed information about significant sustainability-related judgements and assumptions?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Clearly explain the basis for material judgements and estimates. Consider sensitivity analysis for key assumptions."
  },
  {
    id: 8,
    text: "Has your organisation considered and disclosed sustainability-related risks and opportunities across its value chain?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Conduct a value chain analysis to identify sustainability impacts beyond direct operations. Consider engaging with suppliers and customers on sustainability issues."
  },
  {
    id: 9,
    text: "Has your organisation disclosed how sustainability-related financial information relates to information in its financial statements?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Provide clear cross-references between sustainability disclosures and relevant financial statement items. Explain how sustainability factors are reflected in financial planning and performance."
  },
  {
    id: 10,
    text: "Has your organisation disclosed fair presentation principles in its sustainability-related financial disclosures?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Ensure disclosures are balanced, providing both positive and negative aspects of performance. Explain the rationale for inclusion or exclusion of specific information."
  }
];
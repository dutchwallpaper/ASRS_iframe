import { QuestionType } from '../types';

export const aasbs2Questions: QuestionType[] = [
  {
    id: 1,
    text: "Has your organisation disclosed information about the governance processes, controls, and procedures used to monitor and manage climate-related risks and opportunities?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Ensure your disclosure includes board oversight and management's role in assessing and managing climate-related risks and opportunities. Consider establishing a climate risk committee if not already in place."
  },
  {
    id: 2,
    text: "Has your organisation identified and disclosed climate-related risks and opportunities?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Conduct a comprehensive climate risk and opportunity assessment. Consider both physical risks (e.g., extreme weather events) and transition risks (e.g., policy changes, market shifts)."
  },
  {
    id: 3,
    text: "Has your organisation disclosed current and anticipated effects of climate-related risks and opportunities on its business model and value chain?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Analyze how climate change might impact your operations, supply chain, and customer demand. Consider scenario analysis to explore potential future impacts."
  },
  {
    id: 4,
    text: "Has your organisation disclosed information about its strategy and decision-making, including transition plans (if any)?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Develop a clear climate strategy and transition plan. Ensure it's integrated with your overall business strategy and includes specific actions and timelines."
  },
  {
    id: 5,
    text: "Has your organisation disclosed current and anticipated effects of climate-related risks and opportunities on its financial position, financial performance, and cash flows?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Quantify potential financial impacts where possible. Consider both risks (e.g., increased costs) and opportunities (e.g., new markets)."
  },
  {
    id: 6,
    text: "Has your organisation conducted and disclosed climate resilience and scenario analysis?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Conduct scenario analysis using at least two climate scenarios, including one aligned with limiting warming to 1.5°C and another exceeding 2°C. Consider engaging external experts if needed."
  },
  {
    id: 7,
    text: "Has your organisation disclosed information about how climate-related risks and opportunities are identified, assessed, and managed?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Describe your risk management processes specific to climate issues. Ensure integration with overall risk management framework."
  },
  {
    id: 8,
    text: "Has your organisation disclosed its Scope 1 and Scope 2 greenhouse gas (GHG) emissions?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Ensure you have robust systems in place to measure and report Scope 1 and 2 emissions. Consider third-party verification of your emissions data."
  },
  {
    id: 9,
    text: "Has your organisation disclosed its Scope 3 GHG emissions?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "While not mandatory yet, start preparing to measure and disclose Scope 3 emissions. Focus on material categories in your value chain."
  },
  {
    id: 10,
    text: "Has your organisation disclosed climate-related targets and performance against these targets?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Set clear, measurable targets aligned with climate science. Regularly track and report progress. Consider aligning with recognized frameworks like Science Based Targets initiative."
  },
  {
    id: 11,
    text: "Has your organisation prepared an annual sustainability report as part of its annual reporting?",
    isMandatory: true,
    options: ["Yes", "No", "In progress"],
    mitigationSuggestion: "Ensure your sustainability report includes all required elements: climate statements, accompanying notes, and directors' declaration."
  },
  {
    id: 12,
    text: "Does the sustainability report include a climate statement for the relevant year, including applicable notes?",
    isMandatory: true,
    options: ["Yes", "No", "Partially"],
    mitigationSuggestion: "Focus on material climate-related financial risks and opportunities, metrics and targets (including GHG emissions), and information about governance, strategy, and risk management."
  },
  {
    id: 13,
    text: "Has your organisation included a directors' declaration that statements are compliant with AASB S2?",
    isMandatory: true,
    options: ["Yes", "No"],
    mitigationSuggestion: "Ensure directors are fully informed about AASB S2 requirements and the company's climate-related disclosures before signing the declaration."
  },
  {
    id: 14,
    text: "Has your organisation had its sustainability report content audited before providing it to members and lodging with ASIC?",
    isMandatory: true,
    options: ["Yes", "No", "In progress"],
    mitigationSuggestion: "Consider engaging with auditors early in the reporting process to ensure smooth audit procedures. Maintain robust documentation of all climate-related data and processes."
  }
];
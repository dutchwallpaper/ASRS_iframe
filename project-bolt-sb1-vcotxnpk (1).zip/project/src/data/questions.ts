import { QuestionType } from '../types';

export const questions: QuestionType[] = [
  {
    id: 1,
    text: "Is your organisation required to report under Chapter 2M of the Corporations Act?",
    isMandatory: true,
    options: ["Yes", "No"],
    mitigationSuggestion: "If unsure, consult your financial reporting team or legal advisor. Reporting under Chapter 2M is typically required for public companies, large proprietary companies, and registered schemes."
  },
  {
    id: 2,
    text: "Is your organisation an asset owner (Registerable Superannuation Entity, Registered Scheme, or Retail CCIV)?",
    isMandatory: true,
    options: ["Yes", "No"],
    dependsOn: {
      questionId: 1,
      answers: ["Yes"]
    },
    mitigationSuggestion: "If you're unsure, check your organisation's registration status with ASIC or consult with your compliance team."
  },
  {
    id: 3,
    text: "What is the total value of assets under management?",
    isMandatory: true,
    options: ["Less than $5 billion", "$5 billion or more"],
    dependsOn: {
      questionId: 2,
      answers: ["Yes"]
    },
    mitigationSuggestion: "Consider the most recent valuation of assets under management. If close to the threshold, consider potential near-term changes in asset value."
  },
  {
    id: 4,
    text: "Is your organisation a National Greenhouse and Energy Reporting (NGER) reporter above the publication threshold (50 ktCO2-e Scope 1 and 2 emissions)?",
    isMandatory: true,
    options: ["Yes", "No"],
    dependsOn: {
      questionId: 2,
      answers: ["No"]
    },
    mitigationSuggestion: "If you're unsure, check your most recent NGER report or consult with your sustainability team. Consider future emissions projections if you're close to the threshold."
  },
  {
    id: 5,
    text: "What is your organisation's consolidated revenue for the last financial year?",
    isMandatory: true,
    options: ["Less than $200 million", "$200 million to $499 million", "$500 million or more"],
    dependsOn: {
      questionId: 4,
      answers: ["No"]
    },
    mitigationSuggestion: "Use the most recent audited financial statements. If revenue is close to a threshold, consider projected revenue for the coming year."
  },
  {
    id: 6,
    text: "What is your organisation's consolidated gross assets at the end of the last financial year?",
    isMandatory: true,
    options: ["Less than $1 billion", "$1 billion or more"],
    dependsOn: {
      questionId: 5,
      answers: ["$200 million to $499 million"]
    },
    mitigationSuggestion: "Refer to the most recent balance sheet in your audited financial statements. Consider any significant asset acquisitions or disposals since the last reporting period."
  },
  {
    id: 7,
    text: "How many full-time equivalent employees does your organisation have at the end of the last financial year?",
    isMandatory: true,
    options: ["Less than 500", "500 or more"],
    dependsOn: {
      questionId: 6,
      answers: ["Less than $1 billion"]
    },
    mitigationSuggestion: "Include all full-time employees and calculate part-time employees as a proportion of full-time hours. Consider any planned significant changes in workforce size."
  }
];
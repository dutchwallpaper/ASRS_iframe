import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Home } from 'lucide-react';
import { useAssessmentStore } from '../store/assessmentStore';
import { useAuthStore } from '../store/authStore';
import { aasbs1Questions } from '../data/aasbs1Questions';
import QuestionItem from '../components/QuestionItem';
import ProgressBar from '../components/ProgressBar';
import Header from '../components/Header';

const AASBS1AssessmentPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, isAuthenticated } = useAuthStore();
  const { 
    aasbs1Responses, 
    setAASBS1Response,
    clearAASBS1Assessment,
    calculateAASBS1Result
  } = useAssessmentStore();
  
  const [validationError, setValidationError] = useState('');
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // Clear assessment and scroll to top when component mounts
  useEffect(() => {
    clearAASBS1Assessment();
    window.scrollTo(0, 0);
  }, []);

  const handleAnswerChange = (questionId: number, answer: string) => {
    setAASBS1Response(questionId, answer);
    setValidationError('');
  };

  const validateResponses = () => {
    const unansweredQuestions = aasbs1Questions.filter(
      question => !aasbs1Responses.find(response => response.questionId === question.id)
    );
    
    if (unansweredQuestions.length > 0) {
      setValidationError(`Please answer all questions before proceeding. ${unansweredQuestions.length} questions remaining.`);
      const errorElement = document.querySelector('.error-message');
      if (errorElement) {
        errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return false;
    }
    return true;
  };
  
  const handleViewResults = () => {
    if (validateResponses()) {
      calculateAASBS1Result();
      navigate('/results');
    }
  };
  
  if (!isAuthenticated || !currentUser) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/aasb-s2')}
              className="text-blue-600 hover:text-blue-800"
            >
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">
              AASB S1 General Requirements Assessment
            </h1>
          </div>
        </div>

        {validationError && (
          <div className="error-message mb-4 p-3 bg-red-100 text-red-700 rounded-md">
            {validationError}
          </div>
        )}
        
        <div className="mb-8">
          <ProgressBar 
            currentStep={aasbs1Responses.length} 
            totalSteps={aasbs1Questions.length} 
          />
        </div>
        
        <div className="space-y-6">
          {aasbs1Questions.map((question) => (
            <QuestionItem
              key={question.id}
              question={question}
              response={aasbs1Responses.find(
                (response) => response.questionId === question.id
              )}
              onAnswerChange={handleAnswerChange}
              isVisible={true}
            />
          ))}
        </div>
        
        <div className="flex justify-between mt-8">
          <div className="flex gap-2">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colours"
            >
              <Home size={18} />
              Home
            </button>
            
            <button
              onClick={() => navigate('/aasb-s2')}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colours"
            >
              <ArrowLeft size={18} />
              AASB S2
            </button>
          </div>
          
          <button
            onClick={handleViewResults}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colours"
          >
            View Results
            <ArrowRight size={18} />
          </button>
        </div>
      </main>
    </div>
  );
};

export default AASBS1AssessmentPage;
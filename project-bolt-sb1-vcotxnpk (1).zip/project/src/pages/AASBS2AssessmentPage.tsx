import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Home } from 'lucide-react';
import { useAssessmentStore } from '../store/assessmentStore';
import { useAuthStore } from '../store/authStore';
import { aasbs2Questions } from '../data/aasbs2Questions';
import QuestionItem from '../components/QuestionItem';
import ProgressBar from '../components/ProgressBar';
import AASBS2Result from '../components/AASBS2Result';
import Header from '../components/Header';

const AASBS2AssessmentPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, isAuthenticated } = useAuthStore();
  const { 
    aasbs2Responses, 
    setAASBS2Response,
    clearAASBS2Assessment,
    calculateAASBS2Result
  } = useAssessmentStore();
  
  const [showResults, setShowResults] = useState(false);
  const [validationError, setValidationError] = useState('');
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // Clear assessment when component mounts
  useEffect(() => {
    clearAASBS2Assessment();
  }, []);

  const handleAnswerChange = (questionId: number, answer: string) => {
    setAASBS2Response(questionId, answer);
    setValidationError('');
  };

  const validateResponses = () => {
    const unansweredQuestions = aasbs2Questions.filter(
      question => !aasbs2Responses.find(response => response.questionId === question.id)
    );
    
    if (unansweredQuestions.length > 0) {
      setValidationError(`Please answer all questions before proceeding. ${unansweredQuestions.length} questions remaining.`);
      const errorElement = document.querySelector('.error-message');
      if (errorElement) {
        errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return false;
    }
    return true;
  };
  
  const handleContinue = () => {
    if (validateResponses()) {
      calculateAASBS2Result();
      navigate('/aasb-s1');
    }
  };
  
  if (!isAuthenticated || !currentUser) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {showResults ? (
          <AASBS2Result responses={aasbs2Responses} />
        ) : (
          <>
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('/')}
                  className="text-blue-600 hover:text-blue-800"
                >
                  <ArrowLeft size={20} />
                </button>
                <h1 className="text-2xl font-bold text-gray-900">
                  AASB S2 Climate-related Disclosures Assessment
                </h1>
              </div>
            </div>
            
            {validationError && (
              <div className="error-message mb-4 p-3 bg-red-100 text-red-700 rounded-md">
                {validationError}
              </div>
            )}
            
            <div className="mb-8">
              <ProgressBar currentStep={aasbs2Responses.length} totalSteps={aasbs2Questions.length} />
            </div>
            
            <div className="space-y-6">
              {aasbs2Questions.map((question) => (
                <QuestionItem
                  key={question.id}
                  question={question}
                  response={aasbs2Responses.find(
                    (response) => response.questionId === question.id
                  )}
                  onAnswerChange={handleAnswerChange}
                  isVisible={true}
                />
              ))}
            </div>
            
            <div className="flex justify-between mt-8">
              <button
                onClick={() => navigate('/')}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colours"
              >
                <Home size={18} />
                Return Home
              </button>
              
              <button
                onClick={handleContinue}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colours"
              >
                Continue to AASB S1
                <ArrowRight size={18} />
              </button>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default AASBS2AssessmentPage;
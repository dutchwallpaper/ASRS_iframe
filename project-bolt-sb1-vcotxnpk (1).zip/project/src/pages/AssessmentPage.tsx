import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useAssessmentStore } from '../store/assessmentStore';
import { useAuthStore } from '../store/authStore';
import { questions } from '../data/questions';
import QuestionItem from '../components/QuestionItem';
import AssessmentResult from '../components/AssessmentResult';
import Header from '../components/Header';

const AssessmentPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, isAuthenticated } = useAuthStore();
  const { 
    currentResponses, 
    setResponse, 
    clearCurrentAssessment
  } = useAssessmentStore();
  
  const [showResults, setShowResults] = useState(false);
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // Clear assessment when component mounts
  useEffect(() => {
    clearCurrentAssessment();
  }, []);

  // Get visible questions based on current responses
  const getVisibleQuestions = () => {
    return questions.filter(question => {
      if (!question.dependsOn) return true;
      
      const dependentResponse = currentResponses.find(
        response => response.questionId === question.dependsOn?.questionId
      );
      
      return dependentResponse && question.dependsOn.answers.includes(dependentResponse.answer);
    });
  };

  const visibleQuestions = getVisibleQuestions();
  
  const handleAnswerChange = (questionId: number, answer: string) => {
    setResponse(questionId, answer);
    
    // If answering first question with "No", show results immediately
    if (questionId === 1 && answer === 'No') {
      setShowResults(true);
      return;
    }
    
    // Check if this was the last required question
    const currentQuestion = questions.find(q => q.id === questionId);
    if (currentQuestion) {
      const nextQuestions = questions.filter(q => 
        q.dependsOn?.questionId === questionId && 
        q.dependsOn.answers.includes(answer)
      );
      
      if (nextQuestions.length === 0) {
        // No more dependent questions, show results
        setShowResults(true);
      }
    }
  };
  
  if (!isAuthenticated || !currentUser) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {showResults ? (
          <AssessmentResult responses={currentResponses} />
        ) : (
          <>
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold text-gray-900">
                Company Requirements Assessment
              </h1>
            </div>
            
            <div className="space-y-6">
              {visibleQuestions.map((question) => (
                <QuestionItem
                  key={question.id}
                  question={question}
                  response={currentResponses.find(
                    (response) => response.questionId === question.id
                  )}
                  onAnswerChange={handleAnswerChange}
                  isVisible={true}
                />
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default AssessmentPage;
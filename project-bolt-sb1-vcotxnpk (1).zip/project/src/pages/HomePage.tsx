import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ClipboardCheck, BarChart, Shield, FileText } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import LoginForm from '../components/LoginForm';
import Header from '../components/Header';
import { testFullCompliance } from '../utils/testCompliance';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();
  
  const handleLoginSuccess = () => {
    navigate('/assessment');
  };
  
  const handleStartAssessment = () => {
    navigate('/assessment');
  };

  // Test full compliance
  React.useEffect(() => {
    const results = testFullCompliance();
    console.log('Test Results:', results);
  }, []);
  
  const features = [
    {
      icon: <ClipboardCheck size={24} className="text-blue-600" />,
      title: 'Comprehensive Assessment',
      description: 'Complete a detailed questionnaire covering all aspects of sustainability reporting requirements.'
    },
    {
      icon: <BarChart size={24} className="text-blue-600" />,
      title: 'Compliance Scoring',
      description: 'Receive an instant compliance score with detailed breakdown of strengths and weaknesses.'
    },
    {
      icon: <Shield size={24} className="text-blue-600" />,
      title: 'Mitigation Guidance',
      description: 'Get actionable recommendations to address non-compliant areas and improve your score.'
    },
    {
      icon: <FileText size={24} className="text-blue-600" />,
      title: 'Detailed Reports',
      description: 'Generate comprehensive PDF reports to share with stakeholders and track progress.'
    }
  ];
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Australian Sustainability Reporting Standards Compliance
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Assess your organisation's compliance with Arch's Australian Sustainability Reporting Standards tool and get free actionable recommendations.
          </p>
        </div>
        
        {!isAuthenticated ? (
          <div className="max-w-md mx-auto">
            <LoginForm onSuccess={handleLoginSuccess} />
          </div>
        ) : (
          <div className="flex flex-col items-center space-y-4 mb-16">
            <button
              onClick={handleStartAssessment}
              className="bg-blue-600 hover:bg-blue-700 text-white py-3 px-8 rounded-md text-lg font-medium transition-colors"
            >
              Start New Assessment
            </button>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-6">
              <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 bg-white rounded-lg shadow-md p-8">
          <h2 className="text-2xl font-bold mb-4">About Arch's Australian Sustainability Reporting Assessment</h2>
          <p className="text-gray-700 mb-4">
            Australian organisations are increasingly required to report on sustainability matters in accordance with the Australian Accounting Standards Board (AASB) Sustainability Reporting Standards. These standards align with international frameworks and require disclosure of material information about sustainability-related risks and opportunities.
          </p>
          <p className="text-gray-700 mb-4">
            Our assessment tool helps organisations evaluate their current compliance status, identify gaps, and develop action plans to meet reporting requirements. By completing this assessment, you'll gain valuable insights into your organisation's sustainability reporting readiness.
          </p>
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <div className="flex items-center">
                <ClipboardCheck className="h-6 w-6 text-blue-400" />
                <span className="ml-2 text-lg font-bold">Arch's Sustainability Compliance Assessment Tool</span>
              </div>
              <p className="text-sm text-gray-400 mt-1">
                © 2025 Sustainability Compliance Assessment Tool
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, CheckCircle, AlertTriangle, ArrowLeft, ClipboardList, AlertOctagon, Mail } from 'lucide-react';
import { useAssessmentStore } from '../store/assessmentStore';
import { useAuthStore } from '../store/authStore';
import { aasbs1Questions } from '../data/aasbs1Questions';
import { aasbs2Questions } from '../data/aasbs2Questions';
import Header from '../components/Header';

const ResultsPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuthStore();
  const { currentResponses, aasbs1Result, aasbs2Result } = useAssessmentStore();

  // Redirect if no results
  useEffect(() => {
    if (!aasbs1Result || !aasbs2Result) {
      navigate('/assessment');
    }
  }, [aasbs1Result, aasbs2Result, navigate]);

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!aasbs1Result || !aasbs2Result || !currentUser) {
    return null;
  }

  // Determine risk level and styling for each score
  const getRiskLevel = (score: number) => {
    if (score >= 75) return { 
      level: 'Low Risk', 
      color: 'text-green-600', 
      bg: 'bg-green-50', 
      icon: <CheckCircle size={24} className="text-green-600" />,
      action: 'Maintain and Enhance',
      description: 'Your organization demonstrates strong compliance. Focus on continuous improvement and staying ahead of emerging requirements.'
    };
    if (score >= 50) return { 
      level: 'Medium Risk', 
      color: 'text-orange-600', 
      bg: 'bg-orange-50', 
      icon: <AlertTriangle size={24} className="text-orange-600" />,
      action: 'Strengthen and Improve',
      description: 'Significant progress made but key gaps exist. Prioritize addressing identified weaknesses and building robust systems.'
    };
    return { 
      level: 'High Risk', 
      color: 'text-red-600', 
      bg: 'bg-red-50', 
      icon: <AlertOctagon size={24} className="text-red-600" />,
      action: 'Urgent Action Required',
      description: 'Substantial compliance gaps identified. Immediate action needed to address fundamental requirements.'
    };
  };

  const s1Risk = getRiskLevel(aasbs1Result.overallComplianceScore);
  const s2Risk = getRiskLevel(aasbs2Result.overallComplianceScore);

  // Format category name for display
  const formatCategoryName = (name: string) => {
    if (name === 'riskManagement') return 'Risk Management';
    return name.charAt(0).toUpperCase() + name.slice(1);
  };

  // Generate strength summaries with categorization and best practices
  const getStrengthSummary = (successes: string[], questions: typeof aasbs1Questions | typeof aasbs2Questions) => {
    const categories = {
      governance: {
        items: successes.filter(text => text.toLowerCase().includes('governance') || text.toLowerCase().includes('oversight')),
        bestPractices: [
          'Demonstrates commitment to sustainability at highest organisational levels',
          'Enables effective oversight and accountability',
          'Facilitates integration of sustainability into strategic decision-making',
          'Enhances stakeholder confidence in management approach'
        ]
      },
      riskManagement: {
        items: successes.filter(text => text.toLowerCase().includes('risk')),
        bestPractices: [
          'Supports proactive identification and management of sustainability risks',
          'Enables better resource allocation and risk mitigation',
          'Enhances organisational resilience',
          'Improves stakeholder confidence in risk management capabilities'
        ]
      },
      disclosure: {
        items: successes.filter(text => text.toLowerCase().includes('disclosure') || text.toLowerCase().includes('report')),
        bestPractices: [
          'Demonstrates transparency and accountability to stakeholders',
          'Facilitates comparison with peers and industry benchmarks',
          'Supports informed decision-making by investors',
          'Builds trust with stakeholders through comprehensive reporting'
        ]
      },
      strategy: {
        items: successes.filter(text => text.toLowerCase().includes('strategy') || text.toLowerCase().includes('plan')),
        bestPractices: [
          'Aligns sustainability initiatives with business objectives',
          'Enables long-term value creation',
          'Supports competitive advantage through sustainability leadership',
          'Facilitates effective resource allocation'
        ]
      },
      metrics: {
        items: successes.filter(text => text.toLowerCase().includes('metric') || text.toLowerCase().includes('target')),
        bestPractices: [
          'Enables tracking of progress against objectives',
          'Supports data-driven decision-making',
          'Facilitates performance benchmarking',
          'Demonstrates commitment to measurable improvements'
        ]
      }
    };

    return Object.entries(categories)
      .filter(([_, data]) => data.items.length > 0)
      .map(([category, data]) => ({
        category: formatCategoryName(category),
        items: data.items,
        bestPractices: data.bestPractices
      }));
  };

  // Generate improvement opportunity summaries
  const getImprovementSummary = (suggestions: typeof aasbs1Result.mitigationSuggestions) => {
    const categories = {
      governance: {
        items: suggestions.filter(item => 
          item.questionText.toLowerCase().includes('governance') || 
          item.questionText.toLowerCase().includes('oversight')
        ),
        impact: 'Strong governance is fundamental to effective sustainability management and reporting.'
      },
      riskManagement: {
        items: suggestions.filter(item => 
          item.questionText.toLowerCase().includes('risk')
        ),
        impact: 'Effective risk management is crucial for organisational resilience and stakeholder confidence.'
      },
      disclosure: {
        items: suggestions.filter(item => 
          item.questionText.toLowerCase().includes('disclosure') || 
          item.questionText.toLowerCase().includes('report')
        ),
        impact: 'Comprehensive disclosure practices are essential for maintaining stakeholder trust and meeting regulatory requirements.'
      },
      strategy: {
        items: suggestions.filter(item => 
          item.questionText.toLowerCase().includes('strategy') || 
          item.questionText.toLowerCase().includes('plan')
        ),
        impact: 'Strategic integration of sustainability is key to long-term value creation and competitive advantage.'
      },
      metrics: {
        items: suggestions.filter(item => 
          item.questionText.toLowerCase().includes('metric') || 
          item.questionText.toLowerCase().includes('target')
        ),
        impact: 'Robust metrics and targets are essential for tracking progress and demonstrating performance improvements.'
      }
    };

    return Object.entries(categories)
      .filter(([_, data]) => data.items.length > 0)
      .map(([category, data]) => ({
        category: formatCategoryName(category),
        items: data.items,
        impact: data.impact
      }));
  };

  const s1StrengthSummary = getStrengthSummary(aasbs1Result.compliantAreas, aasbs1Questions);
  const s2StrengthSummary = getStrengthSummary(aasbs2Result.compliantAreas, aasbs2Questions);
  
  const s1ImprovementSummary = getImprovementSummary(aasbs1Result.mitigationSuggestions);
  const s2ImprovementSummary = getImprovementSummary(aasbs2Result.mitigationSuggestions);

  const handleShareViaEmail = () => {
    const subject = encodeURIComponent("Sustainability Compliance Assessment Results");
    const body = encodeURIComponent(`
AASB Sustainability Compliance Assessment Results

Organisation: ${currentUser?.organisation || 'Not specified'}
Assessment Date: ${new Date().toLocaleDateString()}

Overall Scores:
- AASB S2 (Climate-related Disclosures): ${aasbs2Result.overallComplianceScore}% (${s2Risk.level})
- AASB S1 (General Requirements): ${aasbs1Result.overallComplianceScore}% (${s1Risk.level})

Key Strengths:
${s2StrengthSummary.map(cat => `${cat.category}:\n${cat.items.map(item => `- ${item}`).join('\n')}`).join('\n\n')}
${s1StrengthSummary.map(cat => `${cat.category}:\n${cat.items.map(item => `- ${item}`).join('\n')}`).join('\n\n')}

Priority Improvement Areas:
${s2ImprovementSummary.map(cat => `${cat.category}:\n${cat.items.map(item => `- ${item.questionText}\n  Recommendation: ${item.suggestion}`).join('\n')}`).join('\n\n')}
${s1ImprovementSummary.map(cat => `${cat.category}:\n${cat.items.map(item => `- ${item.questionText}\n  Recommendation: ${item.suggestion}`).join('\n')}`).join('\n\n')}

Next Steps:
1. Review the detailed assessment results
2. Develop an action plan for identified gaps
3. Schedule follow-up assessment in 6 months
4. Consider external expertise for complex areas

For more information or assistance, please contact our sustainability team.
    `.trim());

    const mailtoLink = `mailto:?subject=${subject}&body=${body}`;
    window.location.href = mailtoLink;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="flex">
        {/* Main Content */}
        <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center gap-2 mb-6">
            <button
              onClick={() => navigate('/aasb-s1')}
              className="text-blue-600 hover:text-blue-800"
            >
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">
              Combined Assessment Results
            </h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* AASB S2 Score Card */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">AASB S2 Score</h2>
              <div className={`${s2Risk.bg} rounded-lg p-4 mb-4`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-lg font-medium">Climate-related Disclosures</span>
                  {s2Risk.icon}
                </div>
                <p className={`text-3xl font-bold ${s2Risk.color}`}>{aasbs2Result.overallComplianceScore}%</p>
                <p className={`text-sm ${s2Risk.color} mt-1`}>{s2Risk.level}</p>
                <p className="text-sm text-gray-600 mt-2">{s2Risk.description}</p>
              </div>
            </div>

            {/* AASB S1 Score Card */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">AASB S1 Score</h2>
              <div className={`${s1Risk.bg} rounded-lg p-4 mb-4`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-lg font-medium">General Requirements</span>
                  {s1Risk.icon}
                </div>
                <p className={`text-3xl font-bold ${s1Risk.color}`}>{aasbs1Result.overallComplianceScore}%</p>
                <p className={`text-sm ${s1Risk.color} mt-1`}>{s1Risk.level}</p>
                <p className="text-sm text-gray-600 mt-2">{s1Risk.description}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Areas of Success */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">Areas of Success</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">AASB S2 Strengths</h3>
                  {s2StrengthSummary.length > 0 ? (
                    <>
                      {s2StrengthSummary.map((category, index) => (
                        <div key={index} className="mb-6">
                          <div className="bg-green-50 rounded-lg p-4 mb-4">
                            <h4 className="font-medium text-green-800 mb-2">{category.category} Excellence</h4>
                            <ul className="list-disc text-sm text-gray-700 ml-4 space-y-1">
                              {category.items.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                            <div className="mt-3 pt-3 border-t border-green-200">
                              <p className="text-sm font-medium text-green-800 mb-2">Why This Matters:</p>
                              <ul className="list-disc text-sm text-gray-600 ml-4 space-y-1">
                                {category.bestPractices.map((practice, i) => (
                                  <li key={i}>{practice}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      ))}
                    </>
                  ) : (
                    <p className="text-sm text-gray-500 italic">No fully compliant areas identified</p>
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-3">AASB S1 Strengths</h3>
                  {s1StrengthSummary.length > 0 ? (
                    <>
                      {s1StrengthSummary.map((category, index) => (
                        <div key={index} className="mb-6">
                          <div className="bg-green-50 rounded-lg p-4 mb-4">
                            <h4 className="font-medium text-green-800 mb-2">{category.category} Excellence</h4>
                            <ul className="list-disc text-sm text-gray-700 ml-4 space-y-1">
                              {category.items.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                            <div className="mt-3 pt-3 border-t border-green-200">
                              <p className="text-sm font-medium text-green-800 mb-2">Why This Matters:</p>
                              <ul className="list-disc text-sm text-gray-600 ml-4 space-y-1">
                                {category.bestPractices.map((practice, i) => (
                                  <li key={i}>{practice}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      ))}
                    </>
                  ) : (
                    <p className="text-sm text-gray-500 italic">No fully compliant areas identified</p>
                  )}
                </div>
              </div>
            </div>

            {/* Priority Improvement Areas */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">Priority Improvement Areas</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">AASB S2 Improvements</h3>
                  {s2ImprovementSummary.length > 0 ? (
                    <>
                      {s2ImprovementSummary.map((category, index) => (
                        <div key={index} className="mb-6">
                          <div className="bg-orange-50 rounded-lg p-4 mb-4">
                            <h4 className="font-medium text-orange-800 mb-2">{category.category} Opportunities</h4>
                            <p className="text-sm text-gray-700 mb-3">{category.impact}</p>
                            <ul className="list-disc text-sm text-gray-700 ml-4 space-y-2">
                              {category.items.map((item, i) => (
                                <li key={i}>
                                  <p className="font-medium">{item.questionText}</p>
                                  <p className="text-sm text-gray-600 mt-1">{item.suggestion}</p>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </>
                  ) : (
                    <p className="text-sm text-gray-500 italic">No improvement areas identified</p>
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-3">AASB S1 Improvements</h3>
                  {s1ImprovementSummary.length > 0 ? (
                    <>
                      {s1ImprovementSummary.map((category, index) => (
                        <div key={index} className="mb-6">
                          <div className="bg-orange-50 rounded-lg p-4 mb-4">
                            <h4 className="font-medium text-orange-800 mb-2">{category.category} Opportunities</h4>
                            <p className="text-sm text-gray-700 mb-3">{category.impact}</p>
                            <ul className="list-disc text-sm text-gray-700 ml-4 space-y-2">
                              {category.items.map((item, i) => (
                                <li key={i}>
                                  <p className="font-medium">{item.questionText}</p>
                                  <p className="text-sm text-gray-600 mt-1">{item.suggestion}</p>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </>
                  ) : (
                    <p className="text-sm text-gray-500 italic">No improvement areas identified</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="bg-blue-50 rounded-lg shadow-md p-6 mb-8">
            <p className="text-lg text-blue-900 font-medium mb-4">
              ARCH don't just help you comply - we help you thrive.
            </p>
            <p className="text-gray-700">
              If you would like to discuss any of the findings detailed above please get in contact with Byron Davy - Associate Director - Sustainability:{' '}
              <a 
                href="mailto:byron.davy@archservices.com.au" 
                className="text-blue-600 hover:text-blue-800 underline"
              >
                byron.davy@archservices.com.au
              </a>
            </p>
          </div>

          <div className="flex justify-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-md transition-colors"
            >
              <Home size={20} />
              Return to Home
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-md transition-colors"
            >
              <ClipboardList size={20} />
              Print Report
            </button>
            <button
              onClick={handleShareViaEmail}
              className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white py-3 px-6 rounded-md transition-colors"
            >
              <Mail size={20} />
              Share via Email
            </button>
          </div>
        </main>

        {/* Fixed Right Sidebar */}
        <div className="hidden xl:block w-96 fixed right-0 top-0 h-screen overflow-y-auto bg-white shadow-lg p-6 mt-16">
          <h2 className="text-xl font-bold mb-4">Risk Level Guide & Actions</h2>
          <div className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <CheckCircle size={24} className="text-green-600" />
                <div>
                  <p className="font-medium">Low Risk (≥75%)</p>
                  <p className="text-sm text-gray-600">Strong compliance position</p>
                </div>
              </div>
              <div className="ml-9">
                <p className="text-sm text-gray-700 mb-2">Recommended Actions:</p>
                <ul className="list-disc text-sm text-gray-600 ml-4 space-y-1">
                  <li>Document and formalise successful practices</li>
                  <li>Develop advanced monitoring systems</li>
                  <li>Prepare for emerging requirements</li>
                  <li>Share best practices across the organisation</li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <AlertTriangle size={24} className="text-orange-600" />
                <div>
                  <p className="font-medium">Medium Risk (50-74%)</p>
                  <p className="text-sm text-gray-600">Improvement needed</p>
                </div>
              </div>
              <div className="ml-9">
                <p className="text-sm text-gray-700 mb-2">Recommended Actions:</p>
                <ul className="list-disc text-sm text-gray-600 ml-4 space-y-1">
                  <li>Develop action plan for identified gaps</li>
                  <li>Allocate resources to priority areas</li>
                  <li>Establish regular progress reviews</li>
                  <li>Consider external expertise for complex issues</li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-red-50 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <AlertOctagon size={24} className="text-red-600" />
                <div>
                  <p className="font-medium">High Risk (&lt;50%)</p>
                  <p className="text-sm text-gray-600">Urgent attention required</p>
                </div>
              </div>
              <div className="ml-9">
                <p className="text-sm text-gray-700 mb-2">Recommended Actions:</p>
                <ul className="list-disc text-sm text-gray-600 ml-4 space-y-1">
                  <li>Immediate engagement with senior management</li>
                  <li>Seek external expertise and support</li>
                  <li>Develop comprehensive compliance programme</li>
                  <li>Establish weekly progress tracking</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;
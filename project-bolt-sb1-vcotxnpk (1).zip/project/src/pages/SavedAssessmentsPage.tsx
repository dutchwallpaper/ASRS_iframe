import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle } from 'lucide-react';
import { useAssessmentStore } from '../store/assessmentStore';
import { useAuthStore } from '../store/authStore';
import SavedAssessmentsList from '../components/SavedAssessmentsList';
import Header from '../components/Header';
import { SavedAssessment } from '../types';

const SavedAssessmentsPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, isAuthenticated } = useAuthStore();
  const { savedAssessments, loadAssessment } = useAssessmentStore();
  const [userAssessments, setUserAssessments] = useState<SavedAssessment[]>([]);
  const [deleteMessage, setDeleteMessage] = useState('');
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // Filter assessments for current user
  useEffect(() => {
    if (currentUser) {
      const filtered = savedAssessments.filter(
        (assessment) => assessment.userId === currentUser.id
      );
      setUserAssessments(filtered);
    }
  }, [savedAssessments, currentUser]);
  
  const handleLoadAssessment = (assessmentId: string) => {
    loadAssessment(assessmentId);
    navigate('/assessment');
  };
  
  const handleDeleteAssessment = (assessmentId: string) => {
    // Filter out the deleted assessment
    const updatedAssessments = savedAssessments.filter(
      (assessment) => assessment.id !== assessmentId
    );
    
    // Update the store (this is a workaround since we don't have a delete method in the store)
    // In a real application, we would add a proper delete method to the store
    (useAssessmentStore as any).setState({ savedAssessments: updatedAssessments });
    
    setDeleteMessage('Assessment deleted successfully');
    
    setTimeout(() => {
      setDeleteMessage('');
    }, 3000);
  };
  
  const handleStartNewAssessment = () => {
    navigate('/assessment');
  };
  
  if (!isAuthenticated || !currentUser) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            Saved Assessments
          </h1>
          
          <button
            onClick={handleStartNewAssessment}
            className="flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors"
          >
            <PlusCircle size={18} />
            New Assessment
          </button>
        </div>
        
        {deleteMessage && (
          <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-md">
            {deleteMessage}
          </div>
        )}
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <SavedAssessmentsList
            assessments={userAssessments}
            onLoad={handleLoadAssessment}
            onDelete={handleDeleteAssessment}
          />
        </div>
      </main>
    </div>
  );
};

export default SavedAssessmentsPage;
import { create } from 'zustand';
import { UserResponse, AssessmentResult } from '../types';
import { questions } from '../data/questions';
import { aasbs1Questions } from '../data/aasbs1Questions';
import { aasbs2Questions } from '../data/aasbs2Questions';

interface AssessmentState {
  currentResponses: UserResponse[];
  aasbs1Responses: UserResponse[];
  aasbs2Responses: UserResponse[];
  currentResult: AssessmentResult | null;
  aasbs1Result: AssessmentResult | null;
  aasbs2Result: AssessmentResult | null;
  
  // Actions
  setResponse: (questionId: number, answer: string) => void;
  setAASBS1Response: (questionId: number, answer: string) => void;
  setAASBS2Response: (questionId: number, answer: string) => void;
  calculateResult: () => AssessmentResult;
  calculateAASBS1Result: () => AssessmentResult;
  calculateAASBS2Result: () => AssessmentResult;
  clearCurrentAssessment: () => void;
  clearAASBS1Assessment: () => void;
  clearAASBS2Assessment: () => void;
}

export const useAssessmentStore = create<AssessmentState>((set, get) => ({
  currentResponses: [],
  aasbs1Responses: [],
  aasbs2Responses: [],
  currentResult: null,
  aasbs1Result: null,
  aasbs2Result: null,
  
  setResponse: (questionId: number, answer: string) => {
    set((state) => {
      const existingIndex = state.currentResponses.findIndex(
        (response) => response.questionId === questionId
      );
      
      if (existingIndex >= 0) {
        const updatedResponses = [...state.currentResponses];
        updatedResponses[existingIndex] = { questionId, answer };
        return { currentResponses: updatedResponses };
      } else {
        return {
          currentResponses: [...state.currentResponses, { questionId, answer }],
        };
      }
    });
  },

  setAASBS1Response: (questionId: number, answer: string) => {
    set((state) => {
      const existingIndex = state.aasbs1Responses.findIndex(
        (response) => response.questionId === questionId
      );
      
      if (existingIndex >= 0) {
        const updatedResponses = [...state.aasbs1Responses];
        updatedResponses[existingIndex] = { questionId, answer };
        return { aasbs1Responses: updatedResponses };
      } else {
        return {
          aasbs1Responses: [...state.aasbs1Responses, { questionId, answer }],
        };
      }
    });
  },

  setAASBS2Response: (questionId: number, answer: string) => {
    set((state) => {
      const existingIndex = state.aasbs2Responses.findIndex(
        (response) => response.questionId === questionId
      );
      
      if (existingIndex >= 0) {
        const updatedResponses = [...state.aasbs2Responses];
        updatedResponses[existingIndex] = { questionId, answer };
        return { aasbs2Responses: updatedResponses };
      } else {
        return {
          aasbs2Responses: [...state.aasbs2Responses, { questionId, answer }],
        };
      }
    });
  },
  
  calculateResult: () => {
    const { currentResponses } = get();
    
    // Filter mandatory and voluntary questions
    const mandatoryQuestions = questions.filter(q => q.isMandatory);
    const voluntaryQuestions = questions.filter(q => !q.isMandatory);
    
    // Count compliant mandatory questions (Yes answers)
    const mandatoryCompliantCount = mandatoryQuestions.filter(question => {
      const response = currentResponses.find(r => r.questionId === question.id);
      return response && response.answer === 'Yes';
    }).length;
    
    // Count compliant voluntary questions (Yes answers)
    const voluntaryCompliantCount = voluntaryQuestions.filter(question => {
      const response = currentResponses.find(r => r.questionId === question.id);
      return response && response.answer === 'Yes';
    }).length;
    
    // Calculate compliance scores
    const mandatoryComplianceScore = mandatoryQuestions.length > 0 
      ? Math.round((mandatoryCompliantCount / mandatoryQuestions.length) * 100) 
      : 0;
    
    const voluntaryComplianceScore = voluntaryQuestions.length > 0 
      ? Math.round((voluntaryCompliantCount / voluntaryQuestions.length) * 100) 
      : 0;
    
    // Calculate overall compliance score (weighted more towards mandatory)
    const overallComplianceScore = Math.round((mandatoryComplianceScore * 0.8) + (voluntaryComplianceScore * 0.2));
    
    // Determine compliance level
    let complianceLevel = 'High Risk';
    if (overallComplianceScore >= 80) {
      complianceLevel = 'Low Risk';
    } else if (overallComplianceScore >= 40) {
      complianceLevel = 'Medium Risk';
    }
    
    // Identify compliant and non-compliant areas
    const compliantAreas = questions.filter(question => {
      const response = currentResponses.find(r => r.questionId === question.id);
      return response && response.answer === 'Yes';
    }).map(q => q.text);
    
    const nonCompliantAreas = questions.filter(question => {
      const response = currentResponses.find(r => r.questionId === question.id);
      return response && (response.answer === 'No' || response.answer === 'Partially');
    }).map(q => q.text);
    
    // Generate mitigation suggestions
    const mitigationSuggestions = questions.filter(question => {
      const response = currentResponses.find(r => r.questionId === question.id);
      return response && (response.answer === 'No' || response.answer === 'Partially');
    }).map(q => ({
      questionId: q.id,
      questionText: q.text,
      suggestion: q.mitigationSuggestion,
      isMandatory: q.isMandatory
    }));
    
    // Sort mitigation suggestions to prioritize mandatory items
    mitigationSuggestions.sort((a, b) => {
      if (a.isMandatory && !b.isMandatory) return -1;
      if (!a.isMandatory && b.isMandatory) return 1;
      return 0;
    });
    
    const result: AssessmentResult = {
      mandatoryComplianceScore,
      voluntaryComplianceScore,
      overallComplianceScore,
      complianceLevel,
      compliantAreas,
      nonCompliantAreas,
      mitigationSuggestions
    };
    
    set({ currentResult: result });
    return result;
  },

  calculateAASBS1Result: () => {
    const { aasbs1Responses } = get();
    let total = 0;
    let possibleTotal = aasbs1Questions.length;
    
    aasbs1Questions.forEach(question => {
      const response = aasbs1Responses.find(r => r.questionId === question.id);
      if (response) {
        if (response.answer === 'Yes') total += 1;
        else if (response.answer === 'Partially') total += 0.5;
      }
    });
    
    const overallComplianceScore = Math.round((total / possibleTotal) * 100);
    
    // Determine compliance level
    let complianceLevel = 'High Risk';
    if (overallComplianceScore >= 75) {
      complianceLevel = 'Low Risk';
    } else if (overallComplianceScore >= 40) {
      complianceLevel = 'Medium Risk';
    }
    
    const compliantAreas = aasbs1Questions.filter(question => {
      const response = aasbs1Responses.find(r => r.questionId === question.id);
      return response && response.answer === 'Yes';
    }).map(q => q.text);
    
    const nonCompliantAreas = aasbs1Questions.filter(question => {
      const response = aasbs1Responses.find(r => r.questionId === question.id);
      return response && (response.answer === 'No' || response.answer === 'Partially');
    }).map(q => q.text);
    
    const mitigationSuggestions = aasbs1Questions.filter(question => {
      const response = aasbs1Responses.find(r => r.questionId === question.id);
      return response && (response.answer === 'No' || response.answer === 'Partially');
    }).map(q => ({
      questionId: q.id,
      questionText: q.text,
      suggestion: q.mitigationSuggestion,
      isMandatory: q.isMandatory
    }));
    
    const result: AssessmentResult = {
      mandatoryComplianceScore: overallComplianceScore,
      voluntaryComplianceScore: overallComplianceScore,
      overallComplianceScore,
      complianceLevel,
      compliantAreas,
      nonCompliantAreas,
      mitigationSuggestions
    };
    
    set({ aasbs1Result: result });
    return result;
  },

  calculateAASBS2Result: () => {
    const { aasbs2Responses } = get();
    let total = 0;
    let possibleTotal = aasbs2Questions.length;
    
    aasbs2Questions.forEach(question => {
      const response = aasbs2Responses.find(r => r.questionId === question.id);
      if (response) {
        if (response.answer === 'Yes') total += 1;
        else if (response.answer === 'Partially' || response.answer === 'In progress') total += 0.5;
      }
    });
    
    const overallComplianceScore = Math.round((total / possibleTotal) * 100);
    
    // Determine compliance level
    let complianceLevel = 'High Risk';
    if (overallComplianceScore >= 75) {
      complianceLevel = 'Low Risk';
    } else if (overallComplianceScore >= 40) {
      complianceLevel = 'Medium Risk';
    }
    
    const compliantAreas = aasbs2Questions.filter(question => {
      const response = aasbs2Responses.find(r => r.questionId === question.id);
      return response && response.answer === 'Yes';
    }).map(q => q.text);
    
    const nonCompliantAreas = aasbs2Questions.filter(question => {
      const response = aasbs2Responses.find(r => r.questionId === question.id);
      return response && (response.answer === 'No' || response.answer === 'Partially' || response.answer === 'In progress');
    }).map(q => q.text);
    
    const mitigationSuggestions = aasbs2Questions.filter(question => {
      const response = aasbs2Responses.find(r => r.questionId === question.id);
      return response && (response.answer === 'No' || response.answer === 'Partially' || response.answer === 'In progress');
    }).map(q => ({
      questionId: q.id,
      questionText: q.text,
      suggestion: q.mitigationSuggestion,
      isMandatory: q.isMandatory
    }));
    
    const result: AssessmentResult = {
      mandatoryComplianceScore: overallComplianceScore,
      voluntaryComplianceScore: overallComplianceScore,
      overallComplianceScore,
      complianceLevel,
      compliantAreas,
      nonCompliantAreas,
      mitigationSuggestions
    };
    
    set({ aasbs2Result: result });
    return result;
  },
  
  clearCurrentAssessment: () => {
    set({
      currentResponses: [],
      currentResult: null,
      aasbs1Result: null,
      aasbs2Result: null
    });
  },

  clearAASBS1Assessment: () => {
    set({
      aasbs1Responses: [],
      aasbs1Result: null
    });
  },

  clearAASBS2Assessment: () => {
    set({
      aasbs2Responses: [],
      aasbs2Result: null
    });
  }
}));
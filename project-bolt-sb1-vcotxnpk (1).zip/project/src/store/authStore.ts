import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';

interface AuthState {
  currentUser: User | null;
  isAuthenticated: boolean;
  
  // Actions
  login: (email: string, name: string, organisation?: string, position?: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      currentUser: null,
      isAuthenticated: false,
      
      login: (email: string, name: string, organisation?: string, position?: string) => {
        const user: User = {
          id: Date.now().toString(),
          email,
          name,
          organisation,
          position
        };
        
        set({
          currentUser: user,
          isAuthenticated: true
        });
      },
      
      logout: () => {
        set({
          currentUser: null,
          isAuthenticated: false
        });
      }
    }),
    {
      name: 'sustainability-auth-storage'
    }
  )
);
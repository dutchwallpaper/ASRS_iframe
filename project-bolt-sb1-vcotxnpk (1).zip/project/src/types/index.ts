export type QuestionType = {
  id: number;
  text: string;
  isMandatory: boolean;
  options: string[];
  dependsOn?: {
    questionId: number;
    answers: string[];
  };
  mitigationSuggestion: string;
};

export type UserResponse = {
  questionId: number;
  answer: string;
};

export type AssessmentResult = {
  mandatoryComplianceScore: number;
  voluntaryComplianceScore: number;
  overallComplianceScore: number;
  complianceLevel: string;
  compliantAreas: string[];
  nonCompliantAreas: string[];
  mitigationSuggestions: {
    questionId: number;
    questionText: string;
    suggestion: string;
    isMandatory: boolean;
  }[];
};

export type User = {
  id: string;
  email: string;
  name: string;
  organisation?: string;
  position?: string;
};

export type SavedAssessment = {
  id: string;
  userId: string;
  date: string;
  responses: UserResponse[];
  result?: AssessmentResult;
};
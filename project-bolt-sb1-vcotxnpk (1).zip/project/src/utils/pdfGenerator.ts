import jsPDF from 'jspdf';
import { AssessmentResult, UserResponse } from '../types';
import { questions } from '../data/questions';

export const generatePDF = (
  result: AssessmentResult,
  responses: UserResponse[],
  userName: string
): jsPDF => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - 2 * margin;
  
  // Helper function for text wrapping
  const addWrappedText = (text: string, x: number, y: number, maxWidth: number, lineHeight: number) => {
    const lines = doc.splitTextToSize(text, maxWidth);
    doc.text(lines, x, y);
    return y + lineHeight * lines.length;
  };
  
  // Add header
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('Sustainability Compliance Assessment Report', margin, 20);
  
  // Add date and user info
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated for: ${userName}`, margin, 30);
  
  // Format date in Australian format (DD/MM/YYYY)
  const today = new Date();
  const formattedDate = `${today.getDate()}/${today.getMonth() + 1}/${today.getFullYear()}`;
  doc.text(`Date: ${formattedDate}`, margin, 37);
  
  // Add compliance scores
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Compliance Scores', margin, 50);
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Overall Compliance: ${result.overallComplianceScore}% (${result.complianceLevel})`, margin, 58);
  doc.text(`Mandatory Compliance: ${result.mandatoryComplianceScore}%`, margin, 65);
  doc.text(`Voluntary Compliance: ${result.voluntaryComplianceScore}%`, margin, 72);
  
  // Add compliance level legend
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Compliance Level Legend:', margin, 85);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Compliant (80-100%): Meeting all or most sustainability reporting requirements', margin, 92);
  doc.text('Partially Compliant (60-79%): Meeting many key requirements but with significant gaps', margin, 98);
  doc.text('At Risk (40-59%): Meeting some requirements but with major compliance gaps', margin, 104);
  doc.text('High Risk (0-39%): Significant non-compliance with sustainability reporting requirements', margin, 110);
  
  // Add summary section
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Executive Summary', margin, 125);
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  let yPos = 135;
  
  const summaryText = `This report provides an assessment of your organisation's compliance with Australian Sustainability Reporting Standards. Your overall compliance score is ${result.overallComplianceScore}%, which indicates ${result.complianceLevel.toLowerCase()} status. The assessment identified ${result.compliantAreas.length} compliant areas and ${result.nonCompliantAreas.length} areas requiring attention.`;
  
  yPos = addWrappedText(summaryText, margin, yPos, contentWidth, 7) + 10;
  
  // Add compliant areas
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Compliant Areas:', margin, yPos);
  yPos += 8;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  
  if (result.compliantAreas.length > 0) {
    for (let i = 0; i < result.compliantAreas.length; i++) {
      // Check if we need to add a new page
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      
      yPos = addWrappedText(`• ${result.compliantAreas[i]}`, margin, yPos, contentWidth, 5) + 5;
    }
  } else {
    yPos = addWrappedText('No compliant areas identified.', margin, yPos, contentWidth, 5) + 5;
  }
  
  yPos += 5;
  
  // Add non-compliant areas
  // Check if we need to add a new page
  if (yPos > 240) {
    doc.addPage();
    yPos = 20;
  }
  
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Areas Needing Attention:', margin, yPos);
  yPos += 8;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  
  if (result.nonCompliantAreas.length > 0) {
    for (let i = 0; i < result.nonCompliantAreas.length; i++) {
      // Check if we need to add a new page
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      
      yPos = addWrappedText(`• ${result.nonCompliantAreas[i]}`, margin, yPos, contentWidth, 5) + 5;
    }
  } else {
    yPos = addWrappedText('No areas needing attention identified.', margin, yPos, contentWidth, 5) + 5;
  }
  
  yPos += 5;
  
  // Add detailed responses section
  // Check if we need to add a new page
  if (yPos > 220) {
    doc.addPage();
    yPos = 20;
  }
  
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Detailed Assessment', margin, yPos);
  yPos += 10;
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  
  // Loop through all questions and responses
  for (const question of questions) {
    const response = responses.find(r => r.questionId === question.id);
    if (!response) continue;
    
    // Check if we need to add a new page
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFont('helvetica', 'bold');
    yPos = addWrappedText(`Q${question.id}: ${question.text}`, margin, yPos, contentWidth, 7) + 5;
    
    doc.setFont('helvetica', 'normal');
    doc.text(`Response: ${response.answer}`, margin, yPos);
    yPos += 7;
    
    doc.text(`Status: ${question.isMandatory ? 'Mandatory' : 'Voluntary'}`, margin, yPos);
    yPos += 7;
    
    if (response.answer === 'No' || response.answer === 'Partially') {
      doc.setFont('helvetica', 'italic');
      yPos = addWrappedText(`Recommendation: ${question.mitigationSuggestion}`, margin, yPos, contentWidth, 7) + 10;
    } else {
      yPos += 5;
    }
  }
  
  // Add mitigation suggestions section
  if (result.mitigationSuggestions.length > 0) {
    // Check if we need to add a new page
    if (yPos > 220) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('Priority Mitigation Actions', margin, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    
    for (let i = 0; i < Math.min(5, result.mitigationSuggestions.length); i++) {
      const suggestion = result.mitigationSuggestions[i];
      
      // Check if we need to add a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      doc.setFont('helvetica', 'bold');
      yPos = addWrappedText(`${i + 1}. ${suggestion.questionText}`, margin, yPos, contentWidth, 7) + 5;
      
      if (suggestion.isMandatory) {
        doc.setTextColor(255, 0, 0);
        doc.text("Mandatory", margin, yPos);
        doc.setTextColor(0, 0, 0);
        yPos += 7;
      }
      
      doc.setFont('helvetica', 'normal');
      yPos = addWrappedText(suggestion.suggestion, margin, yPos, contentWidth, 7) + 10;
    }
  }
  
  // Add next steps section
  // Check if we need to add a new page
  if (yPos > 220) {
    doc.addPage();
    yPos = 20;
  }
  
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Recommended Next Steps', margin, yPos);
  yPos += 10;
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  
  const nextSteps = [
    "1. Establish a Sustainability Governance Framework: Develop clear roles, responsibilities, and reporting lines for sustainability oversight at board and management levels.",
    "2. Conduct a Comprehensive Climate Risk Assessment: Identify and assess both physical and transition risks specific to your industry and operations following TCFD guidelines.",
    "3. Implement Robust Data Collection Systems: Establish processes and controls for collecting, verifying, and reporting sustainability data, particularly GHG emissions.",
    "4. Develop a Climate Transition Plan: Create a detailed roadmap with specific actions, timelines, and responsibilities to address climate-related risks and opportunities.",
    "5. Engage with Key Stakeholders: Establish structured engagement processes with investors, customers, suppliers, and other stakeholders on sustainability matters.",
    "6. Consider External Assurance: Engage with assurance providers to enhance the credibility and reliability of your sustainability disclosures.",
    "7. Schedule Regular Compliance Reviews: Conduct follow-up assessments every 6-12 months to track progress and adjust strategies as needed."
  ];
  
  for (const step of nextSteps) {
    if (yPos > 270) {
      doc.addPage();
      yPos = 20;
    }
    yPos = addWrappedText(step, margin, yPos, contentWidth, 7) + 7;
  }
  
  // Add footer
  const pageCount = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(10);
    doc.text(`Page ${i} of ${pageCount}`, pageWidth - 40, doc.internal.pageSize.getHeight() - 10);
    doc.text('© 2025 Sustainability Compliance Assessment Tool', margin, doc.internal.pageSize.getHeight() - 10);
  }
  
  return doc;
};
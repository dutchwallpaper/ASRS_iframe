import { useAssessmentStore } from '../store/assessmentStore';
import { aasbs1Questions } from '../data/aasbs1Questions';
import { aasbs2Questions } from '../data/aasbs2Questions';

export const testFullCompliance = () => {
  const store = useAssessmentStore.getState();
  
  // Clear any existing responses
  store.clearCurrentAssessment();
  store.clearAASBS1Assessment();
  store.clearAASBS2Assessment();
  
  // Set all AASB S2 questions to "Yes"
  aasbs2Questions.forEach(question => {
    store.setAASBS2Response(question.id, "Yes");
  });
  
  // Calculate AASB S2 result
  const s2Result = store.calculateAASBS2Result();
  console.log('AASB S2 Score:', s2Result.overallComplianceScore + '%');
  
  // Set all AASB S1 questions to "Yes"
  aasbs1Questions.forEach(question => {
    store.setAASBS1Response(question.id, "Yes");
  });
  
  // Calculate AASB S1 result
  const s1Result = store.calculateAASBS1Result();
  console.log('AASB S1 Score:', s1Result.overallComplianceScore + '%');
  
  return {
    s1Score: s1Result.overallComplianceScore,
    s2Score: s2Result.overallComplianceScore
  };
};